# Motion Lab Cloud Renderer MVP

Headless Chromium & FFmpeg server rendering engine for **Microstock Motion Lab V2.1**.

## Features
- **Headless Chromium Execution:** Renders deterministic MotionLab templates frame by frame.
- **FFmpeg Frame Piping:** Direct PNG buffer streaming into FFmpeg `stdin` to prevent disk thrashing.
- **Google Cloud Run Ready:** Containerized Dockerfile setup.
- **REST API:** Simple `/health`, `/render`, and `/render/:renderId/download` endpoints.

---

## Deployment to Google Cloud Run

### 1. Build and Push Container