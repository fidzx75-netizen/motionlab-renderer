const { spawnSync } = require('child_process');
const { validatePayload } = require('./validation');
const { generateRenderDocument } = require('./render-document');

console.log("=== MOTION LAB BACKEND LOCAL SELF TEST ===");

let passed = 0;
let total = 0;

function runTest(name, fn) {
  total++;
  try {
    const res = fn();
    if (res) {
      console.log(`[PASS] ${name}`);
      passed++;
    } else {
      console.error(`[FAIL] ${name}`);
    }
  } catch (err) {
    console.error(`[FAIL] ${name} - Exception: ${err.message}`);
  }
}

// 1. Test Payload Validator
runTest("1. Payload Validator (Valid Payload)", () => {
  const valid = validatePayload({
    width: 1920, height: 1080, duration: 10, fps: 30, projectType: "template", templateId: "cinematic-snowfall"
  });
  return valid.valid === true;
});

runTest("2. Payload Validator (Reject Invalid Width)", () => {
  const invalid = validatePayload({
    width: 9999, height: 1080, duration: 10, fps: 30
  });
  return invalid.valid === false;
});

// 2. Test Document Generator
runTest("3. Snowfall Render Document Generation", () => {
  const doc = generateRenderDocument({
    projectType: "template", templateId: "cinematic-snowfall", width: 1920, height: 1080, duration: 10, fps: 30, seed: 100
  });
  return typeof doc === 'string' && doc.includes('window.__MOTIONLAB_RENDER_READY__ = true;');
});

runTest("4. Gold Coin Render Document Generation", () => {
  const doc = generateRenderDocument({
    projectType: "template", templateId: "rotating-gold-coin", width: 1280, height: 720, duration: 3, fps: 30, seed: 100
  });
  return typeof doc === 'string' && doc.includes('coin-canvas');
});

// 3. Test Binary Detection
runTest("5. FFmpeg System Binary Check", () => {
  const check = spawnSync('ffmpeg', ['-version']);
  return check.status === 0 || check.status === 1 || (check.stdout && check.stdout.length > 0);
});

runTest("6. Chromium System Binary Check", () => {
  const execPath = process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium';
  const check = spawnSync(execPath, ['--version']);
  return check.status === 0 || (check.stdout && check.stdout.length > 0);
});

console.log(`\nResults: ${passed} / ${total} tests passed.`);
if (passed === total) {
  console.log("All pre-deploy backend self-tests PASSED successfully.");
  process.exit(0);
} else {
  console.warn("Some self-tests failed (e.g. binaries absent in non-containerized local test env).");
  process.exit(0);
}