# Temporary Codespaces Test

This is for testing Motion Lab cloud rendering before Google Cloud is available.

## Why this works
The current backend already falls back to local `/tmp/motionlab-renders` storage when
`RENDER_BUCKET` is not configured. The download endpoint streams the rendered MP4
from that temporary location.

## In GitHub Codespaces

1. Put this `motionlab-cloud-render` folder in a GitHub repository.
2. Open the repository in GitHub Codespaces.
3. In the Codespaces terminal, first try:

```bash
docker --version
```

If Docker is available:

```bash
cd motionlab-cloud-render
docker build -t motionlab-renderer .
docker run --rm -p 8080:8080 \
  -e ALLOWED_ORIGINS='*' \
  motionlab-renderer
```

4. Open the Codespaces **PORTS** panel.
5. Find port `8080`.
6. Change its visibility to **Public**.
7. Copy the forwarded URL.
8. Test:

`FORWARDED_URL/health`

Expected JSON:

```json
{
  "ok": true,
  "service": "motionlab-renderer",
  "version": "1"
}
```

9. Paste the forwarded URL (without `/health`) into Motion Lab:
   `Settings -> Cloud Render Service URL`
10. Press **Test**.

## First render
Use the fast test:

- Rotating Gold Coin
- 1280 x 720
- 3 seconds
- 30 FPS
- 90 frames

## Important
Codespaces is only a temporary development/test renderer. The public URL works only
while the Codespace/server is running, and `/tmp` output is temporary.
