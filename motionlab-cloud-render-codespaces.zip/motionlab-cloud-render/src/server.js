const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { validatePayload } = require('./validation');
const { renderVideo } = require('./renderer');
const { uploadToStorage, getLocalFilePath } = require('./storage');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors({
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : '*'
}));

app.use(express.json({ limit: '10mb' }));

// 1. HEALTH ENDPOINT
app.get('/health', (req, res) => {
  res.json({
    ok: true,
    service: "motionlab-renderer",
    version: "1"
  });
});

// 2. POST /render ENDPOINT
app.post('/render', async (req, res) => {
  const payload = req.body;

  // Stage 1: Validation
  const validation = validatePayload(payload);
  if (!validation.valid) {
    return res.status(400).json({
      success: false,
      stage: "validation",
      error: validation.error
    });
  }

  const renderId = 'render_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  const sanitizeName = (payload.projectName || 'motion').toLowerCase().replace(/[^a-z0-9]/g, '-');
  const filename = `${sanitizeName}_${payload.width}x${payload.height}_${payload.fps}fps_${payload.duration}s.mp4`;

  try {
    // Stage 2-5: Frame Rendering & Encoding
    const renderResult = await renderVideo(payload, renderId, filename);

    // Stage 6: Upload / Storage
    const storageResult = await uploadToStorage(renderResult.localFilePath, renderId, filename);

    const response = {
      success: true,
      renderId: renderId,
      filename: filename,
      format: "mp4",
      codec: "h264",
      width: payload.width,
      height: payload.height,
      fps: payload.fps,
      duration: payload.duration,
      frames: renderResult.frames,
      fileSize: renderResult.fileSize,
      downloadUrl: `/render/${renderId}/download?file=${encodeURIComponent(filename)}`
    };

    res.json(response);

  } catch (err) {
    console.error(`[Render Error] [${renderId}]`, err);
    res.status(500).json({
      success: false,
      stage: err.stage || "execution",
      error: err.message || "An error occurred during cloud rendering."
    });
  }
});

// 3. GET /render/:renderId/download ENDPOINT
app.get('/render/:renderId/download', (req, res) => {
  const { renderId } = req.params;
  const filename = req.query.file || `${renderId}.mp4`;
  const filePath = getLocalFilePath(renderId, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ success: false, error: "Render file not found or expired." });
  }

  res.setHeader('Content-Type', 'video/mp4');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  
  const stream = fs.createReadStream(filePath);
  stream.pipe(res);
});

app.listen(PORT, () => {
  console.log(`Motion Lab Renderer listening on port ${PORT}`);
});