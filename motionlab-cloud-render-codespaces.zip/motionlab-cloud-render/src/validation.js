function validatePayload(payload) {
  if (!payload || typeof payload !== 'object') {
    return { valid: false, error: "Missing or invalid payload JSON." };
  }

  const { width, height, duration, fps, projectType, fullHtml, html, javascript } = payload;

  if (!width || typeof width !== 'number' || width <= 0 || width > 1920) {
    return { valid: false, error: "Width must be a positive number <= 1920." };
  }

  if (!height || typeof height !== 'number' || height <= 0 || height > 1920) {
    return { valid: false, error: "Height must be a positive number <= 1920." };
  }

  if (!duration || typeof duration !== 'number' || duration <= 0 || duration > 20) {
    return { valid: false, error: "Duration must be between 1 and 20 seconds for MVP." };
  }

  if (!fps || typeof fps !== 'number' || fps <= 0 || fps > 30) {
    return { valid: false, error: "FPS must be between 1 and 30." };
  }

  if (projectType === 'html') {
    const code = fullHtml || html || javascript || '';
    if (!code.includes('renderMotion')) {
      return { valid: false, error: "HTML project is not MotionLab render compatible (missing renderMotion)." };
    }
  }

  return { valid: true };
}

module.exports = { validatePayload };