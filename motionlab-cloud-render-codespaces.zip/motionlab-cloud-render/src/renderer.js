const puppeteer = require('puppeteer-core');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const { generateRenderDocument } = require('./render-document');
const { getLocalFilePath } = require('./storage');

async function renderVideo(payload, renderId, filename) {
  const { width, height, duration, fps, parameters, seed, loop } = payload;
  const totalFrames = Math.round(duration * fps);
  const outputPath = getLocalFilePath(renderId, filename);

  let browser = null;
  let ffmpegProc = null;

  try {
    // 1. Launch Headless Chromium
    browser = await puppeteer.launch({
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium',
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--hide-scrollbars'
      ]
    });

    const page = await browser.newPage();
    await page.setViewport({ width, height, deviceScaleFactor: 1 });

    // 2. Load Render Document
    const htmlContent = generateRenderDocument(payload);
    await page.setContent(htmlContent, { waitUntil: 'domcontentloaded' });

    // 3. Wait for Ready Signal
    await page.waitForFunction('window.__MOTIONLAB_RENDER_READY__ === true', { timeout: 10000 });

    // 4. Spawn FFmpeg Process with PNG Pipe Input
    ffmpegProc = spawn('ffmpeg', [
      '-y',
      '-f', 'image2pipe',
      '-framerate', String(fps),
      '-vcodec', 'png',
      '-i', 'pipe:0',
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-preset', 'fast',
      '-crf', '18',
      '-movflags', '+faststart',
      outputPath
    ]);

    let ffmpegErrorMsg = '';
    ffmpegProc.stderr.on('data', (chunk) => { ffmpegErrorMsg += chunk.toString(); });

    // 5. Deterministic Frame Loop Pipeline
    for (let frameIndex = 0; frameIndex < totalFrames; frameIndex++) {
      const time = frameIndex / fps;
      const normalizedTime = time / duration;

      await page.evaluate((s) => {
        if (typeof window.renderMotion === 'function') {
          window.renderMotion(s);
        }
      }, {
        time,
        normalizedTime,
        frame: frameIndex,
        duration,
        fps,
        playing: false,
        width,
        height,
        loop: loop !== undefined ? loop : true,
        seed: seed || 100,
        params: parameters || {}
      });

      // Synchronize visual state update
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(resolve)));

      // Screenshot frame as PNG buffer and pipe directly to FFmpeg
      const pngBuffer = await page.screenshot({ type: 'png', omitBackground: false });
      
      const canWrite = ffmpegProc.stdin.write(pngBuffer);
      if (!canWrite) {
        await new Promise(resolve => ffmpegProc.stdin.once('drain', resolve));
      }
    }

    ffmpegProc.stdin.end();

    // 6. Wait for FFmpeg completion
    await new Promise((resolve, reject) => {
      ffmpegProc.on('close', (code) => {
        if (code === 0) resolve();
        else {
          const err = new Error(`FFmpeg exited with code ${code}: ${ffmpegErrorMsg.slice(-300)}`);
          err.stage = "encoding";
          reject(err);
        }
      });
    });

    if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0) {
      const err = new Error("Output MP4 file is empty or was not created.");
      err.stage = "encoding";
      throw err;
    }

    const fileSize = fs.statSync(outputPath).size;

    return {
      localFilePath: outputPath,
      frames: totalFrames,
      fileSize: fileSize
    };

  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = { renderVideo };