function generateRenderDocument(payload) {
  const { projectType, templateId, fullHtml, html, css, javascript, parameters, seed, width, height, duration, fps } = payload;

  if (projectType === 'template' && templateId === 'cinematic-snowfall') {
    return generateSnowfallHtml(payload);
  } else if (projectType === 'template' && templateId === 'rotating-gold-coin') {
    return generateGoldCoinHtml(payload);
  } else if (projectType === 'html' || fullHtml) {
    return injectBridgeIntoUserHtml(fullHtml || assembleSeparateHtml(html, css, javascript), payload);
  }

  throw new Error(`Unsupported project type or template: ${projectType}/${templateId}`);
}

function generateSnowfallHtml(p) {
  const initialParams = JSON.stringify(p.parameters || {});
  return `<!DOCTYPE html>
<html>
<head>
<style>
html, body { margin: 0; width: 100%; height: 100%; overflow: hidden; background: #090e1a; }
canvas { display: block; width: 100%; height: 100%; }
</style>
</head>
<body>
<canvas id="snow-canvas"></canvas>
<script>
const MotionMath = {
  seededRandom: function(seed, index) {
    let s = Math.sin((seed + index * 9301 + 49297) % 233280) * 10000;
    return s - Math.floor(s);
  },
  lerp: function(a, b, t) { return a + (b - a) * t; }
};

window.MotionLab = {
  width: ${p.width}, height: ${p.height}, duration: ${p.duration}, fps: ${p.fps},
  seed: ${p.seed || 100}, params: ${initialParams}
};

const canvas = document.getElementById("snow-canvas");
const ctx = canvas.getContext("2d");

window.renderMotion = function(state) {
  const w = state.width || ${p.width};
  const h = state.height || ${p.height};
  if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }

  const params = state.params || {};
  const seed = Number(params.seed ?? ${p.seed || 100});
  const bgColor = params.bgColor || "#090e1a";
  const snowColor = params.snowColor || "#eef6ff";
  const amount = Number(params.amount ?? 500);
  const baseSize = Number(params.size ?? 1.0);
  const fallSpeedParam = Number(params.fallSpeed ?? 1.0);
  const windStrength = Number(params.windStrength ?? 0.4);
  const windDirection = Number(params.windDirection ?? 0.2);
  const depthAmount = Number(params.depthAmount ?? 0.7);
  const showFG = params.showForeground !== undefined ? Boolean(params.showForeground) : true;
  const opacityParam = Number(params.opacity ?? 0.85);

  const dur = state.duration || ${p.duration};
  const t = (state.time || 0) % dur;
  const tNorm = t / dur;

  ctx.fillStyle = bgColor;
  ctx.fillRect(0, 0, w, h);

  const grad = ctx.createRadialGradient(w/2, h/2, 50, w/2, h/2, Math.max(w, h)*0.7);
  grad.addColorStop(0, "rgba(255,255,255,0.04)");
  grad.addColorStop(1, "rgba(0,0,0,0.45)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  const particles = [];
  for (let i = 0; i < amount; i++) {
    const r0 = MotionMath.seededRandom(seed, i * 7 + 1);
    const r1 = MotionMath.seededRandom(seed, i * 7 + 2);
    const r2 = MotionMath.seededRandom(seed, i * 7 + 3);
    const r4 = MotionMath.seededRandom(seed, i * 7 + 5);
    const r5 = MotionMath.seededRandom(seed, i * 7 + 6);

    const depth = MotionMath.lerp(1.0 - depthAmount * 0.8, 1.0, r0);
    const isForeground = depth > 0.85;

    const baseX = r1 * w;
    const baseY = r2 * h;

    const size = baseSize * (2.0 + depth * 3.5) * (0.6 + r2 * 0.8);
    const fallRate = (150 + depth * 400) * fallSpeedParam * (0.8 + r4 * 0.4);

    const currentY = (baseY + fallRate * t) % h;
    const driftWave = Math.sin(tNorm * 2 * Math.PI * 2 + r5 * Math.PI * 2) * (20 + depth * 40 * windStrength);
    const windOffset = t * windDirection * windStrength * 120 * depth;
    const currentX = (baseX + windOffset + driftWave) % w;
    const finalX = currentX < 0 ? currentX + w : currentX;

    const alpha = (0.25 + depth * 0.75) * (0.6 + r2 * 0.4) * opacityParam;

    particles.push({ x: finalX, y: currentY, size: size, depth: depth, alpha: alpha, isForeground: isForeground });
  }

  particles.sort((a, b) => a.depth - b.depth);

  for (let i = 0; i < particles.length; i++) {
    const pt = particles[i];
    ctx.save();
    ctx.globalAlpha = pt.alpha;

    if (pt.isForeground && showFG) {
      const fgGrad = ctx.createRadialGradient(pt.x, pt.y, 0, pt.x, pt.y, pt.size * 1.8);
      fgGrad.addColorStop(0, snowColor);
      fgGrad.addColorStop(0.4, snowColor);
      fgGrad.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = fgGrad;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * 1.8, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = snowColor;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
};

window.__MOTIONLAB_RENDER_READY__ = true;
</script>
</body>
</html>`;
}

function generateGoldCoinHtml(p) {
  const initialParams = JSON.stringify(p.parameters || {});
  return `<!DOCTYPE html>
<html>
<head>
<style>
html, body { margin: 0; width: 100%; height: 100%; overflow: hidden; background: #05070d; }
canvas { display: block; width: 100%; height: 100%; }
</style>
</head>
<body>
<canvas id="coin-canvas"></canvas>
<script>
window.MotionLab = {
  width: ${p.width}, height: ${p.height}, duration: ${p.duration}, fps: ${p.fps},
  seed: ${p.seed || 100}, params: ${initialParams}
};

const canvas = document.getElementById("coin-canvas");
const ctx = canvas.getContext("2d");

window.renderMotion = function(state) {
  const w = state.width || ${p.width};
  const h = state.height || ${p.height};
  if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }

  const params = state.params || {};
  const coinColor = params.coinColor || "#ffd700";
  const edgeColor = params.edgeColor || "#b8860b";
  const speed = Number(params.speed ?? 1.0);
  const scale = Number(params.scale ?? 1.0);
  const shine = Number(params.shine ?? 0.8);

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#05070d";
  ctx.fillRect(0, 0, w, h);

  const dur = state.duration || ${p.duration};
  const t = (state.time || 0) % dur;
  const angle = (t / dur) * speed * Math.PI * 2;
  const cosA = Math.cos(angle);
  const sinA = Math.sin(angle);

  const cx = w / 2;
  const cy = h / 2;
  const radius = Math.min(w, h) * 0.25 * scale;
  const faceWidth = Math.max(3, Math.abs(cosA) * radius);

  ctx.save();
  ctx.translate(cx, cy);

  const thickness = 14 * scale;
  const edgeDirection = sinA > 0 ? 1 : -1;
  ctx.fillStyle = edgeColor;
  ctx.beginPath();
  ctx.ellipse(edgeDirection * thickness * 0.5, 0, faceWidth, radius, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = coinColor;
  ctx.beginPath();
  ctx.ellipse(0, 0, faceWidth, radius, 0, 0, Math.PI * 2);
  ctx.fill();

  if (shine > 0) {
    const grad = ctx.createLinearGradient(-faceWidth, -radius, faceWidth, radius);
    grad.addColorStop(0, "rgba(255,255,255,0)");
    grad.addColorStop(0.5, "rgba(255,255,255," + (shine * 0.5) + ")");
    grad.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(0, 0, faceWidth, radius, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.strokeStyle = edgeColor;
  ctx.lineWidth = Math.max(1, 3 * scale);
  ctx.beginPath();
  ctx.ellipse(0, 0, faceWidth * 0.7, radius * 0.7, 0, 0, Math.PI * 2);
  ctx.stroke();

  ctx.restore();
};

window.__MOTIONLAB_RENDER_READY__ = true;
</script>
</body>
</html>`;
}

function assembleSeparateHtml(html, css, js) {
  return `<!DOCTYPE html>
<html>
<head><style>${css || ''}</style></head>
<body>
${html || ''}
<script>${js || ''}<\/script>
</body>
</html>`;
}

function injectBridgeIntoUserHtml(rawHtml, p) {
  const initialParams = JSON.stringify(p.parameters || {});
  const bridge = `
<script>
window.MotionLab = {
  width: ${p.width}, height: ${p.height}, duration: ${p.duration}, fps: ${p.fps},
  seed: ${p.seed || 100}, params: ${initialParams}
};
window.__MOTIONLAB_RENDER_READY__ = true;
<\/script>`;

  return rawHtml.includes('</body>') ? rawHtml.replace('</body>', bridge + '\n</body>') : rawHtml + bridge;
}

module.exports = { generateRenderDocument };