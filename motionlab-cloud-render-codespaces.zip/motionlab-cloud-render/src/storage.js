const fs = require('fs');
const path = require('path');
const { Storage } = require('@google-cloud/storage');

const TEMP_DIR = path.join('/tmp', 'motionlab-renders');
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

function getLocalFilePath(renderId, filename) {
  const dir = path.join(TEMP_DIR, renderId);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return path.join(dir, filename);
}

async function uploadToStorage(localFilePath, renderId, filename) {
  const bucketName = process.env.RENDER_BUCKET;
  if (!bucketName) {
    return { uploaded: false, destination: localFilePath };
  }

  try {
    const storage = new Storage();
    const destination = `renders/${renderId}/${filename}`;
    await storage.bucket(bucketName).upload(localFilePath, {
      destination: destination,
      metadata: { cacheControl: 'public, max-age=31536000' }
    });

    return { uploaded: true, destination: destination };
  } catch (err) {
    console.warn("[GCS Upload Warning]", err.message);
    return { uploaded: false, destination: localFilePath };
  }
}

module.exports = { getLocalFilePath, uploadToStorage };